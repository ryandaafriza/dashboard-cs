import React from 'react';
import { Topbar } from '../shared/components/Topbar';
import { KPISection } from '../features/kpi/components/KPISection';
import { SummarySection } from '../features/summary/components/SummarySection';
import { PrioritySection } from '../features/priority/components/PrioritySection';
import { ChannelSection } from '../features/channel/components/ChannelSection';
import { useDashboardData } from '../features/kpi/hooks/useDashboardData';

export function DashboardPage() {
  const { data, loading, refresh } = useDashboardData();

  return (
    <div className="dashboard-page">
      <Topbar
        lastSync={data.lastSync}
        onRefresh={refresh}
        loading={loading}
        dateRange={data.dateRange}
      />
      <main className="dashboard-content">
        <KPISection data={data} />
        <SummarySection summary={data.summary} />
        <PrioritySection priority={data.priority} />
        <ChannelSection />
      </main>
    </div>
  );
}
