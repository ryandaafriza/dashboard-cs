import React from 'react';
import { formatNumber } from '../utils/formatUtils';

/* ─────────────────────────────────────────
   Created Today Card
───────────────────────────────────────── */
export function CreatedTodayCard({ value, delta }) {
  return (
    <div className="card stat-card animate-in">
      <div className="card__inner">
        <div className="card-header">
          <span className="card-label">Created Today</span>
          <span className="card-icon card-icon--info">📋</span>
        </div>
        <div className="stat-value">{formatNumber(value)}</div>
        <div className="stat-meta stat-meta--positive">
          <span>▲</span>
          <span>+{formatNumber(delta)} vs last day</span>
        </div>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────
   Open Tickets Card
───────────────────────────────────────── */
export function OpenTicketsCard({ value }) {
  return (
    <div className="card stat-card animate-in">
      <div className="card__inner">
        <div className="card-header">
          <span className="card-label">Open Tickets</span>
          <span className="card-icon card-icon--warning">⏳</span>
        </div>
        <div className="stat-value" style={{ color: 'var(--color-warning)' }}>
          {formatNumber(value)}
        </div>
        <div className="stat-meta">Active &amp; pending</div>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────
   Unassigned Card
───────────────────────────────────────── */
export function UnassignedCard() {
  return (
    <div className="card stat-card unassigned-card animate-in">
      <div className="card__inner">
        <div className="card-header">
          <span className="card-label">Unassigned</span>
          <span className="card-icon card-icon--danger unassigned-blink">⚠</span>
        </div>
        <div className="unassigned-dots">•••</div>
        <div className="unassigned-label">Needs attention</div>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────
   CSAT Card
───────────────────────────────────────── */
export function CSATCard({ percentage, score }) {
  const circumference = 2 * Math.PI * 26;
  const offset = circumference - (percentage / 100) * circumference;

  return (
    <div className="card csat-card animate-in">
      <div className="card__inner">
        <div className="card-header">
          <span className="card-label">CSAT</span>
          <span className="card-icon card-icon--success">★</span>
        </div>

        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 'var(--space-3)',
            marginTop: 'auto',
          }}
        >
          <div className="csat-ring-wrap">
            <svg width="72" height="72" viewBox="0 0 60 60">
              {/* Track */}
              <circle
                cx="30"
                cy="30"
                r="26"
                fill="none"
                stroke="rgba(255,255,255,0.06)"
                strokeWidth="5"
              />
              {/* Fill */}
              <circle
                cx="30"
                cy="30"
                r="26"
                fill="none"
                stroke="#22c55e"
                strokeWidth="5"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={offset}
                style={{ transition: 'stroke-dashoffset 1.2s ease' }}
              />
            </svg>
            <div className="csat-ring-center">{percentage}%</div>
          </div>

          <div>
            <div className="csat-score">{score.toFixed(2)}</div>
            <div className="csat-sub">/ 5.00 score</div>
          </div>
        </div>
      </div>
    </div>
  );
}
