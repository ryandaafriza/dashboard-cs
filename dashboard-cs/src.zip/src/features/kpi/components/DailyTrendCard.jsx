import React, { useMemo } from 'react';
import { buildLinePath, buildAreaPath } from '../utils/chartUtils';

const W = 320;
const H = 72;

export function DailyTrendCard({ data }) {
  const { path: linePath, points } = useMemo(
    () => buildLinePath(data, W, H, 6),
    [data]
  );
  const areaPath = useMemo(() => buildAreaPath(data, W, H, 6), [data]);

  return (
    <div className="card chart-card animate-in">
      <div className="card__inner">
        <div className="card-header">
          <span className="card-label">Daily Trend</span>
        </div>

        <div className="chart-area">
          <svg
            viewBox={`0 0 ${W} ${H}`}
            preserveAspectRatio="none"
            style={{ width: '100%', height: '100%' }}
          >
            <defs>
              <linearGradient id="trendGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.18" />
                <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
              </linearGradient>
            </defs>
            {areaPath && (
              <path d={areaPath} fill="url(#trendGrad)" />
            )}
            {linePath && (
              <path
                d={linePath}
                fill="none"
                stroke="#3b82f6"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            )}
            {points.length > 0 && (
              <circle
                cx={points[points.length - 1].x}
                cy={points[points.length - 1].y}
                r="3"
                fill="#3b82f6"
              />
            )}
          </svg>
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
          {data
            .filter((_, i) => i % 3 === 0)
            .map((d) => (
              <span
                key={d.time}
                style={{ fontSize: 10, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}
              >
                {d.time}
              </span>
            ))}
        </div>
      </div>
    </div>
  );
}
