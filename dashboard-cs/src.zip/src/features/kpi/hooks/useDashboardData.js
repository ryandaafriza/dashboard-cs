import { useState, useCallback } from 'react';

const MOCK_DATA = {
  slaToday: 57.66,
  slaDelta: -26.17,
  slaStatus: 'Achieved',

  dailyTrend: [
    { time: '06', value: 95 },
    { time: '07', value: 180 },
    { time: '08', value: 260 },
    { time: '09', value: 310 },
    { time: '10', value: 285 },
    { time: '11', value: 220 },
    { time: '12', value: 195 },
    { time: '13', value: 240 },
    { time: '14', value: 200 },
    { time: '15', value: 175 },
    { time: '16', value: 155 },
    { time: '17', value: 130 },
  ],

  ticketsPerHour: [
    { hour: '00', created: 12, solved: 8 },
    { hour: '01', created: 8, solved: 5 },
    { hour: '02', created: 6, solved: 4 },
    { hour: '03', created: 5, solved: 3 },
    { hour: '04', created: 7, solved: 6 },
    { hour: '05', created: 14, solved: 10 },
    { hour: '06', created: 45, solved: 38 },
    { hour: '07', created: 89, solved: 72 },
    { hour: '08', created: 134, solved: 98 },
    { hour: '09', created: 178, solved: 145 },
    { hour: '10', created: 162, solved: 130 },
    { hour: '11', created: 143, solved: 118 },
    { hour: '12', created: 120, solved: 95 },
  ],

  createdToday: 1295,
  createdDelta: 394,
  openTickets: 390,
  unassigned: null,

  csat: { percentage: 94, score: 4.69 },

  summary: { total: 1169, open: 390, closed: 779 },

  priority: {
    roaming: 13,
    extra_quota: 1,
    cc: 0,
    vip: 0,
    p1: 23,
    urgent: 7,
  },

  lastSync: '2026-04-18 13:15:02',
  dateRange: 'Apr 18, 2026',
};

export function useDashboardData() {
  const [data, setData] = useState(MOCK_DATA);
  const [loading, setLoading] = useState(false);

  const refresh = useCallback(() => {
    setLoading(true);
    setTimeout(() => {
      setData({ ...MOCK_DATA, lastSync: new Date().toLocaleString('id-ID') });
      setLoading(false);
    }, 800);
  }, []);

  return { data, loading, refresh };
}
