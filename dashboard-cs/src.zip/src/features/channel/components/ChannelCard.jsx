import React from 'react';
import { CHANNEL_CONFIG } from '../utils/channelUtils';
import { ChannelMetrics } from './ChannelMetrics';
import { ChannelTable } from './ChannelTable';

export function ChannelCard({ channel }) {
  const config = CHANNEL_CONFIG[channel.key] ?? {
    label: channel.key,
    icon: '•',
    color: '#8a95a8',
    gradient: 'transparent',
  };

  return (
    <div className="card channel-card animate-in" style={{ '--ch-color': config.color }}>
      <div className="card__inner channel-card__inner" style={{ background: config.gradient }}>

        {/* Header */}
        <div className="channel-card__header">
          <div className="channel-card__title">
            <span className="channel-card__icon">{config.icon}</span>
            <span className="channel-card__label">{config.label}</span>
          </div>
        </div>

        {/* Metrics row */}
        <ChannelMetrics sla={channel.sla} open={channel.open} closed={channel.closed} />

        {/* Divider */}
        <div className="channel-card__divider" />

        {/* Tables */}
        <div className="channel-card__tables">
          <ChannelTable
            title="Top Corporate"
            rows={channel.topCorporate}
            color={config.color}
          />
          <ChannelTable
            title="Top KIP"
            rows={channel.topKip}
            color={config.color}
          />
        </div>
      </div>
    </div>
  );
}
