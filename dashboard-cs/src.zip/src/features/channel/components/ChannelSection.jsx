import React from 'react';
import { ChannelCard } from './ChannelCard';
import { useChannelData } from '../hooks/useChannelData';

export function ChannelSection() {
  const { channels } = useChannelData();

  return (
    <section>
      <div className="section-label">Channel Performance</div>
      <div className="channel-section-grid">
        {channels.map((ch) => (
          <ChannelCard key={ch.key} channel={ch} />
        ))}
      </div>
    </section>
  );
}
