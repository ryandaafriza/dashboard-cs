import { useMemo } from 'react';

const CHANNEL_DATA = [
  {
    key: 'email',
    sla: 55.07,
    open: 373,
    closed: 653,
    topCorporate: [
      { name: 'PT. Super Spring', interactions: 21, tickets: 0, fcr: 95.24 },
      { name: 'PT. Indomarco Primatama', interactions: 8, tickets: 0, fcr: 55.96 },
      { name: 'PT. Unisfield Networks Indonesia', interactions: 7, tickets: 0, fcr: 80.11 },
      { name: 'PT. Kriv Glass Indonesia', interactions: 5, tickets: 0, fcr: 100 },
      { name: 'Australian Embassy', interactions: 5, tickets: 1, fcr: 80 },
    ],
    topKip: [
      { name: 'Permintaan PDT Billing', interactions: 95, tickets: 0, fcr: 73.68 },
      { name: 'Informasi activasi paket', interactions: 50, tickets: 0, fcr: 55.42 },
      { name: 'Permintaan activasi paket (Scheduling)', interactions: 47, tickets: 0, fcr: 100 },
      { name: 'Referensi Berlangganan atau Activate Terminasi', interactions: 46, tickets: 0, fcr: 50.33 },
      { name: 'Activasi kartu SIM', interactions: 28, tickets: 1, fcr: 0 },
    ],
  },
  {
    key: 'whatsapp',
    sla: 100,
    open: 0,
    closed: 36,
    topCorporate: [
      { name: 'Spam Global Solusindo', interactions: 27, tickets: 0, fcr: 100 },
      { name: 'Unilever Indonesia Tbk', interactions: 3, tickets: 0, fcr: 100 },
      { name: 'PT. Bank Mandiri (Persero) Tbk', interactions: 2, tickets: 0, fcr: 100 },
      { name: 'Vale Indonesia Tbk', interactions: 2, tickets: 0, fcr: 50 },
      { name: 'PT. Inti Indonesia', interactions: 1, tickets: 0, fcr: 0 },
    ],
    topKip: [
      { name: 'Informasi tata kuota', interactions: 75, tickets: 0, fcr: 100 },
      { name: 'Permintaan Refresh GPRS', interactions: 12, tickets: 0, fcr: 100 },
      { name: 'Informasi status nomor', interactions: 4, tickets: 0, fcr: 100 },
      { name: 'Permintaan kepemilikan atau mutasi (Corp to Corp)', interactions: 3, tickets: 0, fcr: 100 },
      { name: 'Pasang baru', interactions: 1, tickets: 0, fcr: 0 },
    ],
  },
  {
    key: 'social_media',
    sla: 100,
    open: 0,
    closed: 9,
    topCorporate: [
      { name: 'PT. Lateka Bangguh Nusantara', interactions: 1, tickets: 0, fcr: 86.67 },
      { name: 'PT. Ebeni Technosantara', interactions: 1, tickets: 0, fcr: 34.33 },
      { name: 'Consumer', interactions: 1, tickets: 0, fcr: 100 },
      { name: 'PT. Andalan Fluid Sistem', interactions: 1, tickets: 0, fcr: 100 },
      { name: 'PT. Rahmat Alam Samudra', interactions: 1, tickets: 0, fcr: 0 },
    ],
    topKip: [
      { name: 'Informasi status nomor', interactions: 3, tickets: 0, fcr: 50 },
      { name: 'Tidak Bisa Connect ke Internet', interactions: 2, tickets: 0, fcr: 100 },
      { name: 'Informasi tata kuota', interactions: 1, tickets: 0, fcr: 100 },
      { name: 'Kami kepemilikan atau mutasi (Corp to Corp)', interactions: 1, tickets: 0, fcr: 100 },
      { name: 'Kendala activasi kartu SIM', interactions: 1, tickets: 0, fcr: 0 },
    ],
  },
  {
    key: 'live_chat',
    sla: 69.57,
    open: 13,
    closed: 79,
    topCorporate: [
      { name: 'Evian Kinara Agalia', interactions: 2, tickets: 0, fcr: 100 },
      { name: 'PT. Alam Organic Makmur', interactions: 2, tickets: 0, fcr: 100 },
      { name: 'Creative Industries Abadi', interactions: 2, tickets: 0, fcr: 50 },
      { name: 'IL Naga Cinta Senbada', interactions: 2, tickets: 0, fcr: 0 },
    ],
    topKip: [
      { name: 'Permintaan PDT Billing', interactions: 11, tickets: 0, fcr: 54.55 },
      { name: 'Informasi tata kuota', interactions: 8, tickets: 0, fcr: 100 },
      { name: 'Permintaan Refresh GPRS', interactions: 6, tickets: 0, fcr: 100 },
      { name: 'Terminasi Tahun Pajak', interactions: 5, tickets: 0, fcr: 100 },
      { name: 'Kendala download detail invoice MCL', interactions: 3, tickets: 0, fcr: 0 },
    ],
  },
  {
    key: 'call_center',
    sla: 0,
    open: 4,
    closed: 2,
    topCorporate: [],
    topKip: [],
  },
];

export function useChannelData() {
  const channels = useMemo(() => CHANNEL_DATA, []);
  return { channels };
}
