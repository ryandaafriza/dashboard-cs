import React from 'react';

export function Topbar({ lastSync, onRefresh, loading, dateRange }) {
  return (
    <header className="topbar">
      <div className="topbar__left">
        <h1 className="topbar__title">Dashboard</h1>
        <span className="topbar__badge">Overview</span>
      </div>

      <div className="topbar__right">
        <div className="sync-info">
          <div className="sync-dot" />
          <span>Last Sync: {lastSync}</span>
        </div>

        <button
          className="sync-btn"
          onClick={onRefresh}
          disabled={loading}
          style={{ opacity: loading ? 0.6 : 1 }}
        >
          <span style={{ display: 'inline-block', animation: loading ? 'spin 0.8s linear infinite' : 'none' }}>
            ↻
          </span>
          Sync Today
        </button>

        <div className="date-range">
          📅 {dateRange}
        </div>
      </div>

      <style>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </header>
  );
}
